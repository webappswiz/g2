<?php
/* WARNING: This config is auto-generated from public_html/site/wp-config.php.backup for wpcli compatibility! */
if (!defined('DB_NAME')) {/*WP-CLI_DEFINITION_CHECK*/
define('DB_NAME', 'goodieb1_wor3462');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('DB_USER')) {/*WP-CLI_DEFINITION_CHECK*/
define('DB_USER', 'goodieb1_wor3462');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('DB_PASSWORD')) {/*WP-CLI_DEFINITION_CHECK*/
define('DB_PASSWORD', 'N3EIJE1Zhrho');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('DB_HOST')) {/*WP-CLI_DEFINITION_CHECK*/
define('DB_HOST', 'localhost');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('DB_CHARSET')) {/*WP-CLI_DEFINITION_CHECK*/
define('DB_CHARSET', 'utf8');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('DB_COLLATE')) {/*WP-CLI_DEFINITION_CHECK*/
define('DB_COLLATE', '');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('AUTH_KEY')) {/*WP-CLI_DEFINITION_CHECK*/
define('AUTH_KEY', '{*kqjh[V^eK&R)=EmH;F{Sl$!O}XSVX@fTY&g?bR}U_L*k<(uQBsu)OAnHoJ?HeJF<b*HZS|SbhHsexv@WhgZ{/?TqmW=C{*zSXTOjzVZ}PixNix[F|u&W|&oc<Y&cI^');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('SECURE_AUTH_KEY')) {/*WP-CLI_DEFINITION_CHECK*/
define('SECURE_AUTH_KEY', 'XQ]HPXy_d}RB|+L($[C?}?%}@rAC^Z|uAX-kRwfL=OfwJXz>L]-xF-w-_TxET*vPlX)WhMLqpsc;L)ZT<G/*iPjwF?=GMSo{JY!gy>]lQ_D[jI%f^&s<p/E={+E*{BL[');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('LOGGED_IN_KEY')) {/*WP-CLI_DEFINITION_CHECK*/
define('LOGGED_IN_KEY', 'VIelD^C[]n(@Zvh<t^La_Mf&/gS<oTl+[};/]|ioP%*KPSLzSR?rJiGL!dCbED^z-ZrhH{P@mKbP(FdohPHS{jK&ekIAvWg?Gu(D%Y_=-<>=}ckjCPjvEs^_agFuOaDm');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('NONCE_KEY')) {/*WP-CLI_DEFINITION_CHECK*/
define('NONCE_KEY', 'yUH!Q?GL!zr;c!y}GRYbVRTDfNsJV!F$]I*tE>|>_*ay]}!jc}w|rPtOHayB)$madx>Ync]p/NEfybGo;g=Ng<%lW;P+=!r*nFltU%+zkbQV-tchswNzW^XO^k|zXyLc');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('AUTH_SALT')) {/*WP-CLI_DEFINITION_CHECK*/
define('AUTH_SALT', '*r]mFAX<WX$E@/(WgQ=)rq=&SpGX]K}G|qY[bS<hc>x;NN)/r&bBqRxrbNCOj-g]KIlf$zH]$aAdw))V)gT=blyb?c@eVnze]Dy?A(@%!iB{QOvN[([yY=)dWrA)<&&+');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('SECURE_AUTH_SALT')) {/*WP-CLI_DEFINITION_CHECK*/
define('SECURE_AUTH_SALT', 'Du&KfUyXsE_N{cCW|ErPvDssFF>Z_|qHMvXMgb+!Ds[$-{LYXIHOUdz|){GL?Xua@Ni+EqfWSNJx_XY=;B!gXpj<yCqJ|XHnyuC^%UMUMw{=FL^icsQ%@eh-tOCddugW');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('LOGGED_IN_SALT')) {/*WP-CLI_DEFINITION_CHECK*/
define('LOGGED_IN_SALT', ']S$)UzbrZ>C?blF-Khm;((WvId/QCMCu=kY>=>DfDib@j_!mY=CT!>tw^]&+<{dl@dyYl}aiKbA(?ms<LIAvLb]Ou_BF@%(<R<kwGy|(/I?rNczA]CnDiq_mT-^Bx}Fn');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('NONCE_SALT')) {/*WP-CLI_DEFINITION_CHECK*/
define('NONCE_SALT', 'ATcxy(J<FyMljrkRW@{TN>b<kS^SUx?<C?ss?KDm_vPdi>XwNuymgUu!Z<)*i_gbaNHAt;l]&OjfmaC>y(CyndEI&|N%gJ!U&YkM-+*glQ%z<psLJ/JU_Jq&]Gee@iAX');

}/*WP-CLI_DEFINITION_CHECK*/
$table_prefix = 'wp_luvw_';
if (!defined('WPLANG')) {/*WP-CLI_DEFINITION_CHECK*/
define('WPLANG', '');

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('WP_DEBUG')) {/*WP-CLI_DEFINITION_CHECK*/
define('WP_DEBUG', false);

}/*WP-CLI_DEFINITION_CHECK*/
if (!defined('ABSPATH')) {/*WP-CLI_DEFINITION_CHECK*/
	define('ABSPATH', dirname(__FILE__) . '/');

}/*WP-CLI_DEFINITION_CHECK*/
require_once(ABSPATH . 'wp-settings.php');
