-- ---------------------------------------------------------
-- Backup with BackWPup ver.: 3.1.2
-- https://marketpress.de/product/backwpup-pro/
-- Blog Name: goodiebox.hu
-- Blog URL: http://www.goodiebox.hu/site/
-- Blog ABSPATH: /home2/goodieb1/public_html/site/
-- Blog Charset: UTF-8
-- Table Prefix: wp_luvw_
-- Database Name: goodieb1_wor3462
-- Backup on: 2015-06-11 19:48.48
-- ---------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='SYSTEM' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


--
-- Table structure for `wp_luvw__wwa_plugin_alerts`
--

DROP TABLE IF EXISTS `wp_luvw__wwa_plugin_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw__wwa_plugin_alerts` (
  `alertId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alertType` tinyint(4) NOT NULL DEFAULT '0',
  `alertSeverity` int(11) NOT NULL DEFAULT '0',
  `alertActionName` varchar(255) NOT NULL,
  `alertTitle` varchar(255) NOT NULL,
  `alertDescription` text NOT NULL,
  `alertSolution` text NOT NULL,
  `alertDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `alertFirstSeen` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`alertId`),
  UNIQUE KEY `alertId_UNIQUE` (`alertId`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw__wwa_plugin_alerts`
--

LOCK TABLES `wp_luvw__wwa_plugin_alerts` WRITE;
/*!40000 ALTER TABLE `wp_luvw__wwa_plugin_alerts` DISABLE KEYS */;
INSERT INTO `wp_luvw__wwa_plugin_alerts` (`alertId`, `alertType`, `alertSeverity`, `alertActionName`, `alertTitle`, `alertDescription`, `alertSolution`, `alertDate`, `alertFirstSeen`) VALUES 
(1, 0, 0, 'fix_wp_version_hidden', 'WordPress version is only displayed to administrator users', '<p>Displaying your WordPress version on frontend and in the backend\'s footer to all visitors\r\n\r\n                        and users of your website is a security risk because if a hacker knows which version of WordPress a website is running, it can make it easier for him to target a known WordPress security issue.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(2, 0, 0, 'fix_wp_generators_frontend', 'WordPress meta tags are only displayed on frontend to administrator users', '<p>By default, WordPress creates a few meta tags, among which is the currently installed version, that give a hacker the knowledge about your WordPress installation.\r\n\r\n                At the moment, all WordPress\'s defaults meta tags are hidden for all users but administrators.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(3, 0, 0, 'fix_wp_rsd_frontend', 'WordPress Really Simple Discovery tag is displayed on frontend to all users', '<p>By default, WordPress creates the <strong>rsd meta tag</strong> to allow bloggers to consume services like Flickr using the <a href=\"http://en.wikipedia.org/wiki/XML-RPC\" target=\"_blank\">XML-RPC</a> protocol.\r\n\r\n                            If you don\'t use such services it is recommended to hide this meta tag.</p>', '<p>This plugin can automatically hide the rsd meta tag if the option <strong>\"Remove Really Simple Discovery meta tags from front-end\"</strong> is checked on the plugin\'s settings page.</p>', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(4, 0, 0, 'fix_wp_wlw_frontend', 'WordPress Windows Live Writer tag is only displayed on frontend for administrator users', '<p>By default, WordPress creates the wlw meta tag to allow bloggers to publish their articles using the <strong>\"Windows Live Writer\"</strong> application.\r\n\r\n                        It is recommended to hide this meta tag from all visitors. If the option <strong>\"Remove Windows Live Writer meta tags from front-end\"</strong> is checked on the plugin\'s settings page, this meta tag\r\n\r\n                        will still be available for administrator users to use the <strong>\"Windows Live Writer\"</strong> application to publish their blog posts.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(24, 0, 0, 'fix_wp_index_plugins', '<strong>\"/wp-content/plugins\"</strong> directory is not secure from directory listing.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n\r\n                            The specific risks and consequences vary depending on which files are listed and accessible.\r\n\r\n                            Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:43:07'),
(5, 0, 3, 'fix_wp_error_reporting', 'The check for PHP and database error reporting is disabled', '<p>By default, WordPress hides database errors, but there are times when a plugin might enable them thus it is very important to have this type of errors turned off\r\n\r\n                            so if there is an error during a connection to the database the user will not get access to the error message generated during that request.</p>\r\n\r\n                            <p>As regarding the PHP errors, with the <strong>display_error</strong> PHP configuration directive enabled, untrusted sources can see detailed web application environment\r\n\r\n                            error messages which include sensitive information that can be used to craft further attacks.</p>\r\n\r\n                            <p>Attackers will do anything to collect information in order to design their attack in a more sophisticated way to eventually hack your website or web application, and causing\r\n\r\n                            errors to display is a common starting point. Website errors can always occur, but they should be suppressed from being displayed back to the public.</p>\r\n\r\n                            <p>Therefore we highly recommend you to have the <strong>\"Disable error reporting (php + db) for all but administrators\"</strong> option checked on the plugin\'s settings page to ensure PHP and\r\n\r\n                            database errors will be hidden from all users. For more information, please check the following <a href=\"http://www.worldwebarts.com/\" target=\"_blank\">article</a>.</p>', '<p>This plugin can do this automatically if the option <strong>\"Disable error reporting (php + db) for all but administrators\"</strong> is checked on the plugin\'s settings page.</p>', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(6, 0, 3, 'fix_wp_core_update_notif', 'Core update notifications are displayed to all users', '<p>These notifications are displayed at the top of the screen by the WordPress platform whenever the website was updated or needs an update.</p>\r\n\r\n                    <p>These notifications should only be viewed by the website\'s administrators and not visible to any other users registered with that website.</p>', '<p>This plugin can automatically hide these notifications if the option <strong>\"Remove core update notifications from back-end for all but administrators\"</strong> is checked on the plugin\'s settings page.</p>', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(7, 0, 2, 'fix_wp_plugins_update_notif', 'Plugins update notifications are displayed to all users', '<p>These notifications are displayed at the top of the screen by the WordPress platform whenever the blog administrator\r\n\r\n                        needs to be informed about an available update for a plugin.</p>\r\n\r\n                    <p>These notifications should only be viewed by the website\'s administrators and not visible to any other users registered with that website.</p>', '<p>This plugin can automatically hide these notifications if the option <strong>\"Remove plug-ins update notifications from back-end\"</strong> is checked on the plugin\'s settings page.</p>', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(8, 0, 0, 'fix_wp_themes_update_notif', 'Themes update notifications are displayed to all users.', '<p>These notifications are displayed at the top of the screen by the WordPress platform whenever the blog administrator\r\n\r\n                        needs to be informed about an available update for a theme.</p>\r\n\r\n                    <p>These notifications should only be viewed by the website\'s administrators and not visible to any other users registered with that website.</p>', '<p>This plugin can automatically hide these notifications if the option <strong>\"Remove themes update notifications from back-end\"</strong> is checked on the plugin\'s settings page.</p>', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(9, 0, 2, 'fix_wp_login_errors', 'WordPress login errors are displayed.', '<p>Every time a failed login is encountered, the WordPress platform generates an error message that is displayed to the user.\r\n\r\n                        This is a potential security risk because it let\'s the user know of his mistake (be it a wrong user name or password) thus making your\r\n\r\n                        WordPress website more vulnerable to attacks.</p>\r\n\r\n                    <p>We strongly recommend you to hide these login error messages from all users to ensure a better security of your blog.</p>', '<p>This plugin can automatically hide these notifications if the option <strong>\"Remove login error notifications from front-end\"</strong> is checked on the plugin\'s settings page.</p>', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(10, 0, 2, 'fix_wp_admin_notices', 'WordPress admin notifications are displayed to all users.', '<p>These notifications are displayed at the top of the screen by the WordPress platform whenever the blog administrator\r\n\r\n                       needs to be informed about an event that has occurred inside WordPress, it could be about an available update for the\r\n\r\n                       WordPress platform, a plugin or a theme that was updated or needs an update or to be configured, etc.</p>\r\n\r\n                    <p>These notifications should only be viewed by the website\'s administrators and not visible to any other users registered with that website.</p>', '<p>This plugin can automatically hide these notifications if the option <strong>\"Hide admin notifications for non admins\"</strong> is checked on the plugin\'s settings page.</p>', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(11, 0, 0, 'fix_wp_dir_listing', 'Directory listing check is enabled.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n\r\n                    The specific risks and consequences vary depending on which files are listed and accessible.\r\n\r\n                    Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(23, 0, 0, 'fix_wp_index_content', '<strong>\"/wp-content\"</strong> directory is secure from directory listing.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n\r\n                    The specific risks and consequences vary depending on which files are listed and accessible.\r\n\r\n                    Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:43:07'),
(12, 0, 0, 'fix_remove_wp_version_links', 'WordPress version displayed in links only for administrator users.', '<p>By default, WordPress will display the current version in links to javascript scripts or stylesheets.\r\n\r\n                    Therefore, if anyone has access to this information it might be a security risk because if a hacker knows which version of WordPress a website is running,\r\n\r\n                    it can make it easier for him to target a known WordPress security issue.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(13, 0, 0, 'fix_empty_root_readme_file', 'The content of the readme.html file from the root directory has been deleted.', '<p>A default WordPress installation contains a readme.html file. This file is a simple html file that does not contain executable content that can be exploited by hackers or malicious users.\r\n\r\n                        Still, this file can provide hackers the version of your WordPress installation, therefore it is important to either delete this file or make it inaccessible for your visitors.</p>', '', '2014-08-18 10:43:07', '2014-08-18 10:29:12'),
(14, 0, 0, 'check_table_prefix', 'The default WordPress database prefix is not used', '<p>The majority of reported WordPress database security attacks were performed by exploiting SQL Injection vulnerabilities.\r\n\r\n                        By renaming the WordPress database table prefixes you are securing your WordPress blog and website from zero day SQL injections attacks.</p>\r\n\r\n                    <p>Therefore by renaming the WordPress database table prefixes, you are automatically enforcing your WordPress database security against such dangerous attacks because the attacker would not be able to guess the table names.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(15, 0, 0, 'check_wp_current_version', 'You have the latest version of WordPress installed', '<p>The latest WordPress version is usually more stable and secure, and is only released to include new features or fix technical and WordPress security bugs;\r\n\r\n                            making it an important part of your website administration to keep up to date since some fixes might resolve security issues.<p>\r\n\r\n                        <p>Running an older WordPress version could put your blog security at risk, allowing a hacker to exploit known vulnerabilities for your specific version and take full control over your web server.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(16, 0, 0, 'check_index_wp_content', 'The <strong>\"index.php\"</strong> file was found in the <strong>\"/wp-content\"</strong> directory', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory. The specific risks and consequences vary depending on which files are listed and accessible.</p>\r\n\r\n                    <p>Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(17, 0, 0, 'check_index_wp_plugins', 'The <strong>\"index.php\"</strong> file was found in the <strong>\"/wp-content/plugins\"</strong> directory', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory. The specific risks and consequences vary depending on which files are listed and accessible.</p>\r\n\r\n                    <p>Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(18, 0, 0, 'check_index_wp_themes', 'The <strong>\"index.php\"</strong> file was found in the <strong>\"/wp-content/themes\"</strong> directory', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory. The specific risks and consequences vary depending on which files are listed and accessible.</p>\r\n\r\n                    <p>Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(19, 0, 0, 'check_index_wp_uploads', 'The <strong>\"index.php\"</strong> file was found in the <strong>\"/wp-content/uploads\"</strong> directory', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory. The specific risks and consequences vary depending on which files are listed and accessible.</p>\r\n\r\n                    <p>Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(20, 0, 2, 'check_htaccess_wp_admin', 'The <strong>\".htaccess\"</strong> file was not found in the <strong>\"wp-admin\"</strong> directory', '<p>An .htaccess file is a configuration file which provides the ability to specify configuration settings for a specific directory in a website.\r\n\r\n                    The .htaccess file can include one or more configuration settings which apply only for the directory in which the .htaccess file has been placed.\r\n\r\n                    So while web servers have their own main configuration settings file, the .htaccess file can be used to override their main configuration settings.</p>', '<p>Please refer to this <a href=\"http://www.worldwebarts.com/\" target=\"_blank\">article</a> for more information on how to create an .htaccess file.</p>', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(21, 0, 0, 'check_readme_wp_root', 'The <strong>readme.html</strong> file is either empty or not accessible.', '<p>A default WordPress installation contains a readme.html file.\r\n\r\n                                This file is a simple html file that does not contain executable content that can be exploited by hackers or malicious users.\r\n\r\n                                Still, this file can provide hackers the version of your WordPress installation, therefore it is important to either delete this file or make it inaccessible for your visitors.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:29:12'),
(22, 0, 0, 'check_username_admin ', 'User <strong>\"admin\"</strong> (with administrative rights) was not found', '<p>One well known and dangerous WordPress security vulnerability is User Enumeration, in which a\r\n\r\n                            malicious user is able to enumerate a valid WordPress user account to launch a brute force attack against it.\r\n\r\n                            In order to protect from this type of attack, it is important not to have the default <a href=\"http://www.worldwebarts.com/\" target=\"_blank\">WordPress administrator</a>\r\n\r\n                            username enabled on your blog.</p>', '', '2014-08-18 10:31:02', '2014-08-18 10:29:13'),
(25, 0, 0, 'fix_wp_index_themes', '<strong>\"/wp-content/themes\"</strong> directory is not secure from directory listing.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n\r\n                            The specific risks and consequences vary depending on which files are listed and accessible.\r\n\r\n                            Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:43:07'),
(26, 0, 0, 'fix_wp_index_uploads', '<strong>\"/wp-content/uploads\"</strong> directory is not secure from directory listing.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n\r\n                            The specific risks and consequences vary depending on which files are listed and accessible.\r\n\r\n                            Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:44:48', '2014-08-18 10:43:07'),
(27, 0, 0, 'fix_wp_index_uploads', '<strong>\"/wp-content/uploads\"</strong> directory is not secure from directory listing.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n\r\n                            The specific risks and consequences vary depending on which files are listed and accessible.\r\n\r\n                            Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-08-18 10:43:07', '2014-08-18 10:43:07');
/*!40000 ALTER TABLE `wp_luvw__wwa_plugin_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw__wwa_plugin_live_traffic`
--

DROP TABLE IF EXISTS `wp_luvw__wwa_plugin_live_traffic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw__wwa_plugin_live_traffic` (
  `entryId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entryTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `entryIp` text,
  `entryReferrer` text,
  `entryUA` text,
  `entryRequestedUrl` text,
  PRIMARY KEY (`entryId`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw__wwa_plugin_live_traffic`
--

LOCK TABLES `wp_luvw__wwa_plugin_live_traffic` WRITE;
/*!40000 ALTER TABLE `wp_luvw__wwa_plugin_live_traffic` DISABLE KEYS */;
INSERT INTO `wp_luvw__wwa_plugin_live_traffic` (`entryId`, `entryTime`, `entryIp`, `entryReferrer`, `entryUA`, `entryRequestedUrl`) VALUES 
(1, '2014-08-18 10:29:26', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(2, '2014-08-18 10:30:38', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_scanner', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwaplugin_glossary_tooltip.js'),
(3, '2014-08-18 10:30:38', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_scanner', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(4, '2014-08-18 10:30:52', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_live_traffic', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(5, '2014-08-18 10:31:04', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminuser', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(6, '2014-08-18 10:31:15', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(7, '2014-08-18 10:36:16', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(8, '2014-08-18 10:36:30', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(9, '2014-08-18 10:36:37', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/gblogin/?action=logout&amp;_wpnonce=4a7963d402'),
(10, '2014-08-18 10:36:38', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/gblogin/?loggedout=true'),
(11, '2014-08-18 10:36:48', '78.131.29.220', '', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/gblogin'),
(12, '2014-08-18 10:36:55', '78.131.29.220', 'http://www.goodiebox.hu/site/gblogin', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/gblogin/'),
(13, '2014-08-18 10:37:11', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(14, '2014-08-18 10:37:17', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(15, '2014-08-18 10:37:21', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/gblogin/?action=logout&amp;_wpnonce=4a7963d402'),
(16, '2014-08-18 10:37:21', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/gblogin/?loggedout=true'),
(17, '2014-08-18 10:37:51', '78.131.29.220', '', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/gblogin/'),
(18, '2014-08-18 10:37:57', '78.131.29.220', 'http://www.goodiebox.hu/site/gblogin/', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/gblogin/'),
(19, '2014-08-18 10:38:14', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(20, '2014-08-18 10:38:19', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_adminurl', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(21, '2014-08-18 10:41:46', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_settings', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(22, '2014-08-18 10:43:07', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_settings', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2'),
(23, '2014-08-18 10:43:13', '78.131.29.220', 'http://www.goodiebox.hu/site/wp-admin/admin.php?page=wwa_settings', 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.143 Safari/537.36', 'http://www.goodiebox.hu/site/wp-content/plugins/wwa-advanced-wp-security/res/js/wwa-util.js?ver=3.9.2');
/*!40000 ALTER TABLE `wp_luvw__wwa_plugin_live_traffic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_commentmeta`
--

DROP TABLE IF EXISTS `wp_luvw_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for `wp_luvw_comments`
--

DROP TABLE IF EXISTS `wp_luvw_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw_comments`
--

LOCK TABLES `wp_luvw_comments` WRITE;
/*!40000 ALTER TABLE `wp_luvw_comments` DISABLE KEYS */;
INSERT INTO `wp_luvw_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES 
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-08-18 16:07:00', '2014-08-18 16:07:00', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0);
/*!40000 ALTER TABLE `wp_luvw_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_links`
--

DROP TABLE IF EXISTS `wp_luvw_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for `wp_luvw_options`
--

DROP TABLE IF EXISTS `wp_luvw_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=512 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw_options`
--

LOCK TABLES `wp_luvw_options` WRITE;
/*!40000 ALTER TABLE `wp_luvw_options` DISABLE KEYS */;
INSERT INTO `wp_luvw_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES 
(1, 'siteurl', 'http://www.goodiebox.hu/site/', 'yes'),
(2, 'blogname', 'goodiebox.hu', 'yes'),
(3, 'blogdescription', 'Meglepetés csomag kutyusodnak minden hónapban', 'yes'),
(4, 'users_can_register', '0', 'yes'),
(5, 'admin_email', 'info@goodiebox.hu', 'yes'),
(6, 'start_of_week', '1', 'yes'),
(7, 'use_balanceTags', '0', 'yes'),
(8, 'use_smilies', '1', 'yes'),
(9, 'require_name_email', '1', 'yes'),
(10, 'comments_notify', '1', 'yes'),
(11, 'posts_per_rss', '10', 'yes'),
(12, 'rss_use_excerpt', '0', 'yes'),
(13, 'mailserver_url', 'mail.example.com', 'yes'),
(14, 'mailserver_login', 'login@example.com', 'yes'),
(15, 'mailserver_pass', 'password', 'yes'),
(16, 'mailserver_port', '110', 'yes'),
(17, 'default_category', '1', 'yes'),
(18, 'default_comment_status', 'open', 'yes'),
(19, 'default_ping_status', 'open', 'yes'),
(20, 'default_pingback_flag', '1', 'yes'),
(21, 'posts_per_page', '10', 'yes'),
(22, 'date_format', 'Y/m/d', 'yes'),
(23, 'time_format', 'g:i a', 'yes'),
(24, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(25, 'comment_moderation', '0', 'yes'),
(26, 'moderation_notify', '1', 'yes'),
(27, 'permalink_structure', '/%postname%/', 'yes'),
(28, 'gzipcompression', '0', 'yes'),
(29, 'hack_file', '0', 'yes'),
(30, 'blog_charset', 'UTF-8', 'yes'),
(31, 'moderation_keys', '', 'no'),
(32, 'active_plugins', 'a:3:{i:0;s:21:\"backwpup/backwpup.php\";i:1;s:19:\"jetpack/jetpack.php\";i:2;s:27:\"woocommerce/woocommerce.php\";}', 'yes'),
(33, 'home', 'http://www.goodiebox.hu/site', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '2', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'twentyfourteen', 'yes'),
(42, 'stylesheet', 'twentyfourteen', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '27918', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '0', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'posts', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_text', 'a:0:{}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:2:{s:48:\"wwa-advanced-wp-security/res/inc/WwaAdminurl.php\";a:2:{i:0;s:15:\"Rename_WP_Login\";i:1;s:9:\"uninstall\";}s:34:\"wwa-advanced-wp-security/index.php\";a:2:{i:0;s:9:\"AntiVirus\";i:1;s:9:\"uninstall\";}}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '0', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '27916', 'yes'),
(89, 'wp_luvw_user_roles', 'a:10:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:115:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:3:{s:4:\"read\";b:1;s:10:\"edit_posts\";b:0;s:12:\"delete_posts\";b:0;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop Manager\";s:12:\"capabilities\";a:93:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:15:\"unfiltered_html\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:14:\"backwpup_admin\";a:2:{s:4:\"name\";s:14:\"BackWPup Admin\";s:12:\"capabilities\";a:10:{s:8:\"backwpup\";b:1;s:13:\"backwpup_jobs\";b:1;s:18:\"backwpup_jobs_edit\";b:1;s:19:\"backwpup_jobs_start\";b:1;s:16:\"backwpup_backups\";b:1;s:25:\"backwpup_backups_download\";b:1;s:23:\"backwpup_backups_delete\";b:1;s:13:\"backwpup_logs\";b:1;s:20:\"backwpup_logs_delete\";b:1;s:17:\"backwpup_settings\";b:1;}}s:14:\"backwpup_check\";a:2:{s:4:\"name\";s:21:\"BackWPup jobs checker\";s:12:\"capabilities\";a:10:{s:8:\"backwpup\";b:1;s:13:\"backwpup_jobs\";b:1;s:18:\"backwpup_jobs_edit\";b:0;s:19:\"backwpup_jobs_start\";b:0;s:16:\"backwpup_backups\";b:1;s:25:\"backwpup_backups_download\";b:0;s:23:\"backwpup_backups_delete\";b:0;s:13:\"backwpup_logs\";b:1;s:20:\"backwpup_logs_delete\";b:0;s:17:\"backwpup_settings\";b:0;}}s:15:\"backwpup_helper\";a:2:{s:4:\"name\";s:20:\"BackWPup jobs helper\";s:12:\"capabilities\";a:10:{s:8:\"backwpup\";b:1;s:13:\"backwpup_jobs\";b:1;s:18:\"backwpup_jobs_edit\";b:0;s:19:\"backwpup_jobs_start\";b:1;s:16:\"backwpup_backups\";b:1;s:25:\"backwpup_backups_download\";b:1;s:23:\"backwpup_backups_delete\";b:1;s:13:\"backwpup_logs\";b:1;s:20:\"backwpup_logs_delete\";b:1;s:17:\"backwpup_settings\";b:0;}}}', 'yes'),
(90, '_transient_random_seed', '6a3dbf691448ca7ec11d1cdf9aeb65f1', 'yes'),
(91, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(92, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(93, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(94, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(95, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(96, 'sidebars_widgets', 'a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(97, 'jetpack_activated', '1', 'yes'),
(98, 'jetpack_options', 'a:10:{s:7:\"version\";s:14:\"3.1:1408378020\";s:11:\"old_version\";s:14:\"3.1:1408378020\";s:28:\"fallback_no_verify_ssl_certs\";i:0;s:9:\"time_diff\";i:0;s:2:\"id\";i:73181932;s:10:\"blog_token\";s:65:\"@9SBXNN21lP5*7uVzffYe(@!cNRny05i.Ol$IrUeeMCO!kOKW%r#KOZW5ovy6QkUs\";s:6:\"public\";i:1;s:11:\"user_tokens\";a:1:{i:1;s:67:\"Y2s%F9QrP#v!Eo(T#AA)p@Bp6&IGWs*s.DclxLaXOXk&U(P#jQNFi@*bJP!4BnHV^.1\";}s:11:\"master_user\";i:1;s:14:\"last_heartbeat\";i:1434044925;}', 'yes'),
(99, 'cron', 'a:16:{i:1433556000;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1434044988;a:1:{s:13:\"backwpup_cron\";a:1:{s:32:\"4ef54d4ada20caa38401a05f7ccc9311\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{s:2:\"id\";s:7:\"restart\";}}}}i:1434046516;a:1:{s:14:\"mm_cron_hourly\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1434046804;a:1:{s:20:\"jetpack_clean_nonces\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1434047352;a:1:{s:24:\"wwa_cleanup_live_traffic\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1434048523;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1434051600;a:1:{s:20:\"wp_maybe_auto_update\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1434055601;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1434070800;a:1:{s:13:\"backwpup_cron\";a:1:{s:32:\"2f35704147e4489fb9b8aeb31dbabaef\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:1:{s:2:\"id\";i:1;}}}}i:1434082506;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1434082516;a:1:{s:18:\"mm_cron_twicedaily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1434082887;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1434083116;a:1:{s:22:\"backwpup_check_cleanup\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1434125716;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:13:\"mm_cron_daily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1434126005;a:1:{s:20:\"jetpack_v2_heartbeat\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(100, 'jpstart_wizard_has_run', '1', 'yes'),
(503, '_site_transient_timeout_theme_roots', '1434046724', 'yes'),
(504, '_site_transient_theme_roots', 'a:3:{s:14:\"twentyfourteen\";s:7:\"/themes\";s:14:\"twentythirteen\";s:7:\"/themes\";s:12:\"twentytwelve\";s:7:\"/themes\";}', 'yes'),
(109, 'mm_master_aff', '', 'yes'),
(110, 'mm_install_date', 'Aug 18, 2014', 'yes'),
(510, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1434044927;s:7:\"checked\";a:3:{s:14:\"twentyfourteen\";s:3:\"1.1\";s:14:\"twentythirteen\";s:3:\"1.2\";s:12:\"twentytwelve\";s:3:\"1.4\";}s:8:\"response\";a:3:{s:14:\"twentyfourteen\";a:4:{s:5:\"theme\";s:14:\"twentyfourteen\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentyfourteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentyfourteen.1.4.zip\";}s:14:\"twentythirteen\";a:4:{s:5:\"theme\";s:14:\"twentythirteen\";s:11:\"new_version\";s:3:\"1.5\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentythirteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentythirteen.1.5.zip\";}s:12:\"twentytwelve\";a:4:{s:5:\"theme\";s:12:\"twentytwelve\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwelve/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwelve.1.7.zip\";}}s:12:\"translations\";a:0:{}}', 'yes'),
(481, 'db_upgraded', '1', 'yes'),
(482, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:4:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.2.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.2.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.2.2\";s:7:\"version\";s:5:\"4.2.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.1\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":12:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.2.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.2.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.2.2\";s:7:\"version\";s:5:\"4.2.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.1\";s:15:\"partial_version\";s:0:\"\";s:12:\"notify_email\";s:1:\"1\";s:13:\"support_email\";s:26:\"updatehelp42@wordpress.org\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.1.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.1.5.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.1.5-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.1.5-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.1.5\";s:7:\"version\";s:5:\"4.1.5\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.1\";s:15:\"partial_version\";s:0:\"\";s:13:\"support_email\";s:26:\"updatehelp42@wordpress.org\";}i:3;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.0.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.0.5.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.0.5-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.0.5-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.0.5\";s:7:\"version\";s:5:\"4.0.5\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.1\";s:15:\"partial_version\";s:0:\"\";s:13:\"support_email\";s:26:\"updatehelp42@wordpress.org\";}}s:12:\"last_checked\";i:1434044923;s:15:\"version_checked\";s:5:\"3.9.6\";s:12:\"translations\";a:0:{}}', 'yes'),
(121, 'mm_cron', 'a:3:{s:5:\"daily\";a:1:{s:14:\"plugin_version\";a:4:{s:1:\"t\";s:5:\"event\";s:2:\"ec\";s:9:\"scheduled\";s:2:\"ea\";s:14:\"plugin_version\";s:2:\"el\";s:5:\"0.5.9\";}}s:6:\"weekly\";a:1:{s:10:\"wp_version\";a:4:{s:1:\"t\";s:5:\"event\";s:2:\"ec\";s:9:\"scheduled\";s:2:\"ea\";s:10:\"wp_version\";s:2:\"el\";s:5:\"3.9.2\";}}s:7:\"monthly\";a:2:{s:12:\"plugin_count\";a:4:{s:1:\"t\";s:5:\"event\";s:2:\"ec\";s:9:\"scheduled\";s:2:\"ea\";s:12:\"plugin_count\";s:2:\"el\";i:4;}s:11:\"theme_count\";a:4:{s:1:\"t\";s:5:\"event\";s:2:\"ec\";s:9:\"scheduled\";s:2:\"ea\";s:11:\"theme_count\";s:2:\"el\";s:14:\"twentyfourteen\";}}}', 'yes'),
(124, 'mm_previous_tests', 'a:1:{i:0;s:17:\"jetpack-start-4.0\";}', 'yes'),
(152, 'jetpack_log', 'a:2:{i:0;a:4:{s:4:\"time\";i:1408378786;s:7:\"user_id\";i:1;s:7:\"blog_id\";b:0;s:4:\"code\";s:8:\"register\";}i:1;a:4:{s:4:\"time\";i:1408378803;s:7:\"user_id\";i:1;s:7:\"blog_id\";i:73181932;s:4:\"code\";s:9:\"authorize\";}}', 'no'),
(150, 'recently_activated', 'a:4:{s:34:\"wwa-advanced-wp-security/index.php\";i:1408380288;s:19:\"akismet/akismet.php\";i:1408378764;s:9:\"hello.php\";i:1408378764;s:37:\"mojo-marketplace/mojo-marketplace.php\";i:1408378764;}', 'yes'),
(156, 'jetpack_active_modules', 'a:22:{i:0;s:10:\"vaultpress\";i:1;s:18:\"verification-tools\";i:3;s:20:\"custom-content-types\";i:5;s:12:\"contact-form\";i:7;s:13:\"subscriptions\";i:9;s:5:\"notes\";i:11;s:10:\"custom-css\";i:13;s:13:\"post-by-email\";i:15;s:10:\"omnisearch\";i:17;s:19:\"gravatar-hovercards\";i:19;s:5:\"latex\";i:21;s:8:\"json-api\";i:23;s:21:\"enhanced-distribution\";i:25;s:5:\"stats\";i:27;s:7:\"widgets\";i:29;s:16:\"gplus-authorship\";i:31;s:10:\"shortlinks\";i:33;s:9:\"publicize\";i:35;s:18:\"after-the-deadline\";i:37;s:10:\"shortcodes\";i:39;s:10:\"sharedaddy\";i:41;s:17:\"widget-visibility\";}', 'yes'),
(158, 'stats_options', 'a:7:{s:9:\"admin_bar\";b:1;s:5:\"roles\";a:1:{i:0;s:13:\"administrator\";}s:11:\"count_roles\";a:0:{}s:7:\"blog_id\";i:73181932;s:12:\"do_not_track\";b:1;s:10:\"hide_smile\";b:1;s:7:\"version\";s:1:\"9\";}', 'yes'),
(163, 'woocommerce_default_country', 'GB', 'yes'),
(164, 'woocommerce_allowed_countries', 'all', 'yes'),
(165, 'woocommerce_specific_allowed_countries', '', 'yes'),
(166, 'woocommerce_demo_store', 'no', 'yes'),
(167, 'woocommerce_demo_store_notice', 'This is a demo store for testing purposes &mdash; no orders shall be fulfilled.', 'no'),
(168, 'woocommerce_api_enabled', 'yes', 'yes'),
(169, 'woocommerce_currency', 'GBP', 'yes'),
(170, 'woocommerce_currency_pos', 'left', 'yes'),
(171, 'woocommerce_price_thousand_sep', ',', 'yes'),
(172, 'woocommerce_price_decimal_sep', '.', 'yes'),
(173, 'woocommerce_price_num_decimals', '2', 'yes'),
(174, 'woocommerce_enable_lightbox', 'yes', 'yes'),
(175, 'woocommerce_enable_chosen', 'yes', 'no'),
(176, 'woocommerce_shop_page_id', '5', 'yes'),
(177, 'woocommerce_shop_page_display', '', 'yes'),
(178, 'woocommerce_category_archive_display', '', 'yes'),
(179, 'woocommerce_default_catalog_orderby', 'title', 'yes'),
(180, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(181, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(182, 'woocommerce_weight_unit', 'kg', 'yes'),
(183, 'woocommerce_dimension_unit', 'cm', 'yes'),
(184, 'woocommerce_enable_review_rating', 'yes', 'no'),
(185, 'woocommerce_review_rating_required', 'yes', 'no'),
(186, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(187, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(188, 'shop_catalog_image_size', 'a:3:{s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";s:4:\"crop\";b:1;}', 'yes'),
(189, 'shop_single_image_size', 'a:3:{s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"300\";s:4:\"crop\";i:1;}', 'yes'),
(190, 'shop_thumbnail_image_size', 'a:3:{s:5:\"width\";s:2:\"90\";s:6:\"height\";s:2:\"90\";s:4:\"crop\";i:1;}', 'yes'),
(191, 'woocommerce_file_download_method', 'force', 'no'),
(192, 'woocommerce_downloads_require_login', 'no', 'no'),
(193, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(194, 'woocommerce_manage_stock', 'yes', 'yes'),
(195, 'woocommerce_hold_stock_minutes', '60', 'no'),
(196, 'woocommerce_notify_low_stock', 'yes', 'no'),
(197, 'woocommerce_notify_no_stock', 'yes', 'no'),
(198, 'woocommerce_stock_email_recipient', 'info@goodiebox.hu', 'no'),
(199, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(200, 'woocommerce_notify_no_stock_amount', '0', 'no'),
(201, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(202, 'woocommerce_stock_format', '', 'yes'),
(203, 'woocommerce_calc_taxes', 'no', 'yes'),
(204, 'woocommerce_prices_include_tax', 'no', 'yes'),
(205, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(206, 'woocommerce_default_customer_address', 'base', 'yes'),
(207, 'woocommerce_shipping_tax_class', 'title', 'yes'),
(208, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(209, 'woocommerce_tax_classes', 'Reduced Rate\nZero Rate', 'yes'),
(210, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(211, 'woocommerce_price_display_suffix', '', 'yes'),
(212, 'woocommerce_tax_display_cart', 'excl', 'no'),
(213, 'woocommerce_tax_total_display', 'itemized', 'no'),
(214, 'woocommerce_enable_coupons', 'yes', 'no'),
(215, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(216, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(217, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(218, 'woocommerce_cart_page_id', '6', 'yes'),
(219, 'woocommerce_checkout_page_id', '7', 'yes'),
(220, 'woocommerce_terms_page_id', '', 'no'),
(221, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(222, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(223, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(224, 'woocommerce_calc_shipping', 'yes', 'yes'),
(225, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(226, 'woocommerce_shipping_cost_requires_address', 'no', 'no'),
(227, 'woocommerce_shipping_method_format', '', 'no'),
(228, 'woocommerce_ship_to_billing', 'yes', 'no'),
(229, 'woocommerce_ship_to_billing_address_only', 'no', 'no'),
(230, 'woocommerce_ship_to_countries', '', 'yes'),
(231, 'woocommerce_specific_ship_to_countries', '', 'yes'),
(232, 'woocommerce_myaccount_page_id', '8', 'yes'),
(233, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(234, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(235, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(236, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(237, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(238, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(239, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(240, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(241, 'woocommerce_registration_generate_username', 'yes', 'no'),
(242, 'woocommerce_registration_generate_password', 'no', 'no'),
(243, 'woocommerce_email_from_name', 'goodiebox.hu', 'no'),
(244, 'woocommerce_email_from_address', 'info@goodiebox.hu', 'no'),
(245, 'woocommerce_email_header_image', '', 'no'),
(246, 'woocommerce_email_footer_text', 'goodiebox.hu - Powered by WooCommerce', 'no'),
(247, 'woocommerce_email_base_color', '#557da1', 'no'),
(248, 'woocommerce_email_background_color', '#f5f5f5', 'no'),
(249, 'woocommerce_email_body_background_color', '#fdfdfd', 'no'),
(250, 'woocommerce_email_text_color', '#505050', 'no'),
(252, 'woocommerce_db_version', '2.1.12', 'yes'),
(253, 'woocommerce_version', '2.1.12', 'yes'),
(264, '_transient_woocommerce_cache_excluded_uris', 'a:6:{i:0;s:3:\"p=6\";i:1;s:3:\"p=7\";i:2;s:3:\"p=8\";i:3;s:5:\"/cart\";i:4;s:9:\"/checkout\";i:5;s:11:\"/my-account\";}', 'yes'),
(265, 'rewrite_rules', 'a:140:{s:14:\"^wc-api\\/v1/?$\";s:24:\"index.php?wc-api-route=/\";s:16:\"^wc-api\\/v1(.*)?\";s:34:\"index.php?wc-api-route=$matches[1]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:28:\"product/([^/]+)(/[0-9]+)?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"product_variation/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:55:\"product_variation/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:75:\"product_variation/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"product_variation/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"product_variation/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"product_variation/([^/]+)/trackback/?$\";s:44:\"index.php?product_variation=$matches[1]&tb=1\";s:46:\"product_variation/([^/]+)/page/?([0-9]{1,})/?$\";s:57:\"index.php?product_variation=$matches[1]&paged=$matches[2]\";s:53:\"product_variation/([^/]+)/comment-page-([0-9]{1,})/?$\";s:57:\"index.php?product_variation=$matches[1]&cpage=$matches[2]\";s:43:\"product_variation/([^/]+)/wc-api(/(.*))?/?$\";s:58:\"index.php?product_variation=$matches[1]&wc-api=$matches[3]\";s:49:\"product_variation/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:60:\"product_variation/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:38:\"product_variation/([^/]+)(/[0-9]+)?/?$\";s:56:\"index.php?product_variation=$matches[1]&page=$matches[2]\";s:34:\"product_variation/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"product_variation/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"product_variation/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"product_variation/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"product_variation/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:20:\"(.?.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:25:\"([^/]+)/wc-api(/(.*))?/?$\";s:45:\"index.php?name=$matches[1]&wc-api=$matches[3]\";s:31:\"[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:20:\"([^/]+)(/[0-9]+)?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";}', 'yes'),
(262, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(338, '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes'),
(259, '_transient_timeout_woocommerce_processing_order_count', '1439914888', 'no'),
(260, '_transient_woocommerce_processing_order_count', '0', 'no'),
(263, 'slurp_page_installed', '1', 'yes'),
(267, 'backwpup_cfg_hash', '13cc91', 'yes'),
(268, 'backwpup_jobs', 'a:1:{i:1;a:20:{s:5:\"jobid\";i:1;s:4:\"type\";a:3:{i:0;s:6:\"DBDUMP\";i:1;s:4:\"FILE\";i:2;s:8:\"WPPLUGIN\";}s:12:\"destinations\";a:1:{i:0;s:6:\"FOLDER\";}s:4:\"name\";s:12:\"Daily Backup\";s:14:\"mailaddresslog\";s:17:\"info@goodiebox.hu\";s:20:\"mailaddresssenderlog\";s:41:\"BackWPup goodiebox.hu <info@goodiebox.hu>\";s:13:\"mailerroronly\";b:1;s:10:\"backuptype\";s:7:\"archive\";s:13:\"archiveformat\";s:7:\".tar.gz\";s:11:\"archivename\";s:33:\"backwpup_13cc91_%Y-%m-%d_%H-%i-%s\";s:9:\"backupdir\";s:76:\"/home2/goodieb1/public_html/site/wp-content/uploads/backwpup-13cc91-backups/\";s:10:\"maxbackups\";i:15;s:18:\"backupsyncnodelete\";b:0;s:10:\"activetype\";s:6:\"wpcron\";s:10:\"cronselect\";s:5:\"basic\";s:4:\"cron\";s:9:\"0 3 * * *\";s:7:\"lastrun\";i:1434052128;s:7:\"logfile\";s:117:\"/home2/goodieb1/public_html/site/wp-content/uploads/backwpup-13cc91-logs/backwpup_log_13cc91_2015-06-11_19-48-48.html\";s:21:\"lastbackupdownloadurl\";s:0:\"\";s:11:\"lastruntime\";i:15;}}', 'no'),
(269, 'backwpup_version', '3.1.2', 'yes'),
(270, 'backwpup_cfg_showadminbar', '1', 'yes'),
(271, 'backwpup_cfg_showfoldersize', '0', 'yes'),
(272, 'backwpup_cfg_protectfolders', '1', 'yes'),
(273, 'backwpup_cfg_jobmaxexecutiontime', '0', 'yes'),
(274, 'backwpup_cfg_jobziparchivemethod', '', 'yes'),
(275, 'backwpup_cfg_jobstepretry', '3', 'yes'),
(276, 'backwpup_cfg_jobsteprestart', '0', 'yes'),
(277, 'backwpup_cfg_jobrunauthkey', '02e7226d', 'yes'),
(278, 'backwpup_cfg_jobnotranslate', '0', 'yes'),
(279, 'backwpup_cfg_jobwaittimems', '0', 'yes'),
(280, 'backwpup_cfg_maxlogs', '30', 'yes'),
(281, 'backwpup_cfg_gzlogs', '0', 'yes'),
(282, 'backwpup_cfg_logfolder', '/home2/goodieb1/public_html/site/wp-content/uploads/backwpup-13cc91-logs/', 'yes'),
(283, 'backwpup_cfg_httpauthuser', '', 'yes'),
(284, 'backwpup_cfg_httpauthpassword', '', 'yes'),
(286, 'backwpup_about_page', '1', 'yes'),
(291, 'backwpup_messages', 'a:0:{}', 'yes'),
(298, 'WWA_PLUGIN_ENTRIES_LIVE_TRAFFIC', '22', 'yes'),
(297, 'rwl_page', 'gblogin', 'yes'),
(299, 'sharing-options', 'a:1:{s:6:\"global\";a:5:{s:12:\"button_style\";s:9:\"icon-text\";s:13:\"sharing_label\";s:11:\"Share this:\";s:10:\"open_links\";s:4:\"same\";s:4:\"show\";a:0:{}s:6:\"custom\";a:0:{}}}', 'yes'),
(339, '_transient_is_multi_author', '0', 'yes'),
(306, 'WWA-RSS-WGT-DISPLAY', 'yes', 'yes'),
(304, 'stats_cache', 'a:2:{s:32:\"edb916868f2de4082113b9989ef02121\";a:1:{i:1408481143;a:0:{}}s:32:\"9b000fdd138198fd6e94d615d0e96746\";a:1:{i:1408481143;a:0:{}}}', 'yes'),
(340, '_transient_twentyfourteen_category_count', '1', 'yes'),
(341, '_transient_timeout_wc_uf_pid_98445f98e21fece4c092bccf3dc7ac25', '1440017260', 'no'),
(342, '_transient_wc_uf_pid_98445f98e21fece4c092bccf3dc7ac25', 'a:1:{i:0;i:9;}', 'no'),
(343, '_transient_timeout_wc_rating_count_9', '1440017261', 'no'),
(344, '_transient_wc_rating_count_9', '0', 'no'),
(345, '_transient_timeout_wc_average_rating_9', '1440017261', 'no'),
(346, '_transient_wc_average_rating_9', '', 'no'),
(416, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:6:\"manual\";s:5:\"email\";s:17:\"info@goodiebox.hu\";s:7:\"version\";s:5:\"4.2.2\";s:9:\"timestamp\";i:1432326262;}', 'yes'),
(507, '_transient_timeout_jetpack_https_test', '1434131325', 'no'),
(508, '_transient_jetpack_https_test', '1', 'no'),
(501, '_transient_doing_cron', '1434044922.5444989204406738281250', 'yes'),
(511, '_site_transient_update_plugins', 'O:8:\"stdClass\":3:{s:12:\"last_checked\";i:1434044927;s:8:\"response\";a:1:{s:21:\"backwpup/backwpup.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"8736\";s:4:\"slug\";s:8:\"backwpup\";s:6:\"plugin\";s:21:\"backwpup/backwpup.php\";s:11:\"new_version\";s:5:\"3.1.4\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/backwpup/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/backwpup.3.1.4.zip\";}}s:12:\"translations\";a:0:{}}', 'yes');
/*!40000 ALTER TABLE `wp_luvw_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_postmeta`
--

DROP TABLE IF EXISTS `wp_luvw_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw_postmeta`
--

LOCK TABLES `wp_luvw_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_luvw_postmeta` DISABLE KEYS */;
INSERT INTO `wp_luvw_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES 
(1, 2, '_wp_page_template', 'default'),
(2, 5, '_wpas_done_all', '1'),
(3, 6, '_wpas_done_all', '1'),
(4, 7, '_wpas_done_all', '1'),
(5, 8, '_wpas_done_all', '1'),
(6, 9, '_edit_last', '1'),
(7, 9, '_edit_lock', '1408482345:1'),
(8, 9, '_visibility', 'visible'),
(9, 9, '_stock_status', 'instock'),
(10, 9, '_wpas_done_all', '1'),
(11, 9, 'total_sales', '0'),
(12, 9, '_downloadable', 'no'),
(13, 9, '_virtual', 'no'),
(14, 9, '_regular_price', '200'),
(15, 9, '_sale_price', ''),
(16, 9, '_purchase_note', ''),
(17, 9, '_featured', 'no'),
(18, 9, '_weight', ''),
(19, 9, '_length', ''),
(20, 9, '_width', ''),
(21, 9, '_height', ''),
(22, 9, '_sku', ''),
(23, 9, '_product_attributes', 'a:0:{}'),
(24, 9, '_sale_price_dates_from', ''),
(25, 9, '_sale_price_dates_to', ''),
(26, 9, '_price', '200'),
(27, 9, '_sold_individually', ''),
(28, 9, '_manage_stock', 'no'),
(29, 9, '_backorders', 'no'),
(30, 9, '_stock', ''),
(31, 9, '_product_image_gallery', '');
/*!40000 ALTER TABLE `wp_luvw_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_posts`
--

DROP TABLE IF EXISTS `wp_luvw_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw_posts`
--

LOCK TABLES `wp_luvw_posts` WRITE;
/*!40000 ALTER TABLE `wp_luvw_posts` DISABLE KEYS */;
INSERT INTO `wp_luvw_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES 
(1, 0, '2014-08-18 16:07:00', '2014-08-18 16:07:00', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-08-18 16:07:00', '2014-08-18 16:07:00', '', 0, 'http://www.goodiebox.hu/site/?p=1', 0, 'post', '', 1),
(2, 0, '2014-08-18 16:07:00', '2014-08-18 16:07:00', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://www.goodiebox.hu/site/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-08-18 16:07:00', '2014-08-18 16:07:00', '', 0, 'http://www.goodiebox.hu/site/?page_id=2', 0, 'page', '', 0),
(4, 1, '2014-08-18 18:21:37', '2014-08-18 16:21:37', '<h1>Checkout</h1>\n\n{{mj-checkout-form}}', 'Mijireh Secure Checkout', '', 'private', 'closed', 'closed', '', 'mijireh-secure-checkout', '', '', '2014-08-18 18:21:37', '2014-08-18 16:21:37', '', 0, 'http://www.goodiebox.hu/site/mijireh-secure-checkout/', 0, 'page', '', 0),
(5, 1, '2014-08-18 18:21:51', '2014-08-18 16:21:51', '', 'Shop', '', 'publish', 'closed', 'open', '', 'shop', '', '', '2014-08-18 18:21:51', '2014-08-18 16:21:51', '', 0, 'http://www.goodiebox.hu/site/shop/', 0, 'page', '', 0),
(6, 1, '2014-08-18 18:21:51', '2014-08-18 16:21:51', '[woocommerce_cart]', 'Cart', '', 'publish', 'closed', 'open', '', 'cart', '', '', '2014-08-18 18:21:51', '2014-08-18 16:21:51', '', 0, 'http://www.goodiebox.hu/site/cart/', 0, 'page', '', 0),
(7, 1, '2014-08-18 18:21:51', '2014-08-18 16:21:51', '[woocommerce_checkout]', 'Checkout', '', 'publish', 'closed', 'open', '', 'checkout', '', '', '2014-08-18 18:21:51', '2014-08-18 16:21:51', '', 0, 'http://www.goodiebox.hu/site/checkout/', 0, 'page', '', 0),
(8, 1, '2014-08-18 18:21:51', '2014-08-18 16:21:51', '[woocommerce_my_account]', 'My Account', '', 'publish', 'closed', 'open', '', 'my-account', '', '', '2014-08-18 18:21:51', '2014-08-18 16:21:51', '', 0, 'http://www.goodiebox.hu/site/my-account/', 0, 'page', '', 0),
(9, 1, '2014-08-19 22:47:12', '2014-08-19 20:47:12', '', 'Kuvasz', '', 'publish', 'open', 'closed', '', 'kuvasz', '', '', '2014-08-19 22:47:12', '2014-08-19 20:47:12', '', 0, 'http://www.goodiebox.hu/site/?post_type=product&#038;p=9', 0, 'product', '', 0);
/*!40000 ALTER TABLE `wp_luvw_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_term_relationships`
--

DROP TABLE IF EXISTS `wp_luvw_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw_term_relationships`
--

LOCK TABLES `wp_luvw_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_luvw_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_luvw_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES 
(1, 1, 0),
(9, 2, 0);
/*!40000 ALTER TABLE `wp_luvw_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_luvw_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw_term_taxonomy`
--

LOCK TABLES `wp_luvw_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_luvw_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_luvw_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES 
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 1),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'shop_order_status', '', 0, 0),
(7, 7, 'shop_order_status', '', 0, 0),
(8, 8, 'shop_order_status', '', 0, 0),
(9, 9, 'shop_order_status', '', 0, 0),
(10, 10, 'shop_order_status', '', 0, 0),
(11, 11, 'shop_order_status', '', 0, 0),
(12, 12, 'shop_order_status', '', 0, 0);
/*!40000 ALTER TABLE `wp_luvw_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_terms`
--

DROP TABLE IF EXISTS `wp_luvw_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw_terms`
--

LOCK TABLES `wp_luvw_terms` WRITE;
/*!40000 ALTER TABLE `wp_luvw_terms` DISABLE KEYS */;
INSERT INTO `wp_luvw_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES 
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'pending', 'pending', 0),
(7, 'failed', 'failed', 0),
(8, 'on-hold', 'on-hold', 0),
(9, 'processing', 'processing', 0),
(10, 'completed', 'completed', 0),
(11, 'refunded', 'refunded', 0),
(12, 'cancelled', 'cancelled', 0);
/*!40000 ALTER TABLE `wp_luvw_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_usermeta`
--

DROP TABLE IF EXISTS `wp_luvw_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw_usermeta`
--

LOCK TABLES `wp_luvw_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_luvw_usermeta` DISABLE KEYS */;
INSERT INTO `wp_luvw_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES 
(1, 1, 'first_name', ''),
(2, 1, 'last_name', ''),
(3, 1, 'nickname', 'webadmin'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_luvw_capabilities', 'a:2:{s:13:\"administrator\";b:1;s:14:\"backwpup_admin\";b:1;}'),
(11, 1, 'wp_luvw_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets'),
(13, 1, 'wp_luvw_dashboard_quick_press_last_post_id', '3'),
(14, 1, '_woocommerce_persistent_cart', 'a:1:{s:4:\"cart\";a:1:{s:32:\"45c48cce2e2d7fbdea1afc51c7c6ad26\";a:8:{s:10:\"product_id\";i:9;s:12:\"variation_id\";s:0:\"\";s:9:\"variation\";s:0:\"\";s:8:\"quantity\";i:1;s:10:\"line_total\";d:200;s:8:\"line_tax\";i:0;s:13:\"line_subtotal\";i:200;s:17:\"line_subtotal_tax\";i:0;}}}');
/*!40000 ALTER TABLE `wp_luvw_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_users`
--

DROP TABLE IF EXISTS `wp_luvw_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup data for table `wp_luvw_users`
--

LOCK TABLES `wp_luvw_users` WRITE;
/*!40000 ALTER TABLE `wp_luvw_users` DISABLE KEYS */;
INSERT INTO `wp_luvw_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES 
(1, 'webadmin', '$P$BhMZU844LgkAOKgDZQVEAqY6Tdfu2S/', 'webadmin', 'info@webappswiz.com', '', '2014-08-18 16:07:00', '', 0, 'webadmin');
/*!40000 ALTER TABLE `wp_luvw_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for `wp_luvw_woocommerce_attribute_taxonomies`
--

DROP TABLE IF EXISTS `wp_luvw_woocommerce_attribute_taxonomies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` longtext,
  `attribute_type` varchar(200) NOT NULL,
  `attribute_orderby` varchar(200) NOT NULL,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for `wp_luvw_woocommerce_downloadable_product_permissions`
--

DROP TABLE IF EXISTS `wp_luvw_woocommerce_downloadable_product_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`,`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for `wp_luvw_woocommerce_order_itemmeta`
--

DROP TABLE IF EXISTS `wp_luvw_woocommerce_order_itemmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for `wp_luvw_woocommerce_order_items`
--

DROP TABLE IF EXISTS `wp_luvw_woocommerce_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for `wp_luvw_woocommerce_tax_rate_locations`
--

DROP TABLE IF EXISTS `wp_luvw_woocommerce_tax_rate_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(255) NOT NULL,
  `tax_rate_id` bigint(20) NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for `wp_luvw_woocommerce_tax_rates`
--

DROP TABLE IF EXISTS `wp_luvw_woocommerce_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) NOT NULL DEFAULT '',
  `tax_rate` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) NOT NULL,
  `tax_rate_class` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`),
  KEY `tax_rate_class` (`tax_rate_class`),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for `wp_luvw_woocommerce_termmeta`
--

DROP TABLE IF EXISTS `wp_luvw_woocommerce_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = 'utf8' */;
CREATE TABLE `wp_luvw_woocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `woocommerce_term_id` (`woocommerce_term_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Backup routines for database 'goodieb1_wor3462'
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Backup completed on 2015-06-11 19:48:48
